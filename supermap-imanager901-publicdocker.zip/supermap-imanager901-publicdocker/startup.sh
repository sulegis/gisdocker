#!/bin/bash -e
Current_DIR=$(cd `dirname $0`; pwd)


advertiseAddr=$1
if [ "$advertiseAddr"x = x  ]; then
  echo "Paas the host IP, for example, use './startup.sh 192.168.17.123' to Start iManager"
  exit 0;
fi

echo "IMANAGER_HOST_IP=$advertiseAddr" > .env

mkdir -p /opt/compose/bin
cp $Current_DIR/docker-compose.sh /opt/compose/bin/docker-compose
chmod +x /opt/compose/bin/docker-compose

sudo sysctl -w vm.max_map_count=262144
/opt/compose/bin/docker-compose -f $Current_DIR/docker-compose.yml pull
echo "# GIS Images Ready, Starting Now... #"
/opt/compose/bin/docker-compose -f $Current_DIR/docker-compose.yml -p imanager up -d