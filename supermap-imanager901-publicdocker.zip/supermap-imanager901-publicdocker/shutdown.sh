#!/bin/bash -e
Current_DIR=$(cd `dirname $0`; pwd)
/opt/compose/bin/docker-compose -f $Current_DIR/docker-compose.yml -p imanager stop